package com.itheima.microservice.service1.api;

/**
 * Created by Administrator.
 */
public interface ConsumerService {
    public String service();
}
