package com.itheima.microservice.service2.api;

/**
 * Created by Administrator.
 */
public interface ProviderService {
    String service();
}
